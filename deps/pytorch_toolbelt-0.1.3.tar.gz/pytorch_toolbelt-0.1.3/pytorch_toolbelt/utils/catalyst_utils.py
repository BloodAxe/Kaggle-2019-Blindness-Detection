import warnings
from pytorch_toolbelt.utils.catalyst import *

warnings.warn('Please use \'from pytorch_toolbelt.utils.catalyst import *\' instead')
